javac -d . -cp .:JNI.jar ../../../Source/MediaInfoDLL/MediaInfoDLL.JNI.java ../../../Source/Example/HowToUse_Dll.java
