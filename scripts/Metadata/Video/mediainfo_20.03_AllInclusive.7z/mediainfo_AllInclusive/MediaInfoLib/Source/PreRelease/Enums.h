#include <ZenLib/Ztring.h>
ZenLib::Ztring Enums_Create ();
